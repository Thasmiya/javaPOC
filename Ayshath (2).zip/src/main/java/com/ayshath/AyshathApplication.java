package com.ayshath;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AyshathApplication {
    public static void main(String[] args) {
        SpringApplication.run(AyshathApplication.class, args);
    }
}
